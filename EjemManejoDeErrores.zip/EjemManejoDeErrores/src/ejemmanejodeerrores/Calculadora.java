/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemmanejodeerrores;

/**
 *
 * @author mirko
 */
public class Calculadora 
{
    // Suma de dos enteros
    public int operar(int a, int b) {
        return a + b;
    }

    // Resta de dos enteros
    public int operar(int a, int b, char operador) {
        if (operador == '-') 
        {
            return a - b;
        } else if (operador == '*') {
            return a * b;
        } else if (operador == '/') {
            if (b == 0) {
                throw new ArithmeticException("No se puede dividir entre cero.");
            }
            return a / b;
        } else {
            throw new IllegalArgumentException("Operador no válido.");
        }
    }
}
