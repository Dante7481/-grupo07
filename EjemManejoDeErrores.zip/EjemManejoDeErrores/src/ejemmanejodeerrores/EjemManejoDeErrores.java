/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemmanejodeerrores;
import java.util.Scanner;

/**
 *
 * @author mirko
 */
public class EjemManejoDeErrores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        Calculadora calc = new Calculadora();

        try {
            System.out.print("Ingrese el primer numero: ");
            int num1 = sc.nextInt();

            System.out.print("Ingrese el segundo numero: ");
            int num2 = sc.nextInt();

            System.out.print("Ingrese el operador (+, -, *, /): ");
            char operador = sc.next().charAt(0);

            int resultado;

            if (operador == '+') {
                resultado = calc.operar(num1, num2);
            } else {
                resultado = calc.operar(num1, num2, operador);
            }

            System.out.println("Resultado: " + resultado);

        } catch (ArithmeticException e) {
            System.out.println("Error aritmetico: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Entrada invalida.");
        } finally {
            sc.close();
        }
    }  
}
