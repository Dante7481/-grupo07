/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejmsobrecarga;

/**
 *
 * @author UCLAB300
 */
public class Calculadora {
    public void sumar(double a, double b){
        double rpta= a+b;
        System.out.println("la suma es: "+ rpta);
    }
    public static void sumar(double a, double b, double c){
        double rpta= a+b+c;
        System.out.println("la suma es: "+ rpta);
    }
    public static void sumar(double a, double b, double c, double d){
        double rpta= a+b+c+d;
        System.out.println("la suma es: "+ rpta);
    }
    public void dividir(int a, int b){
        int rpta=0;
        try{
        rpta = a/b;
        System.out.println("La respuesta es: " + rpta);
        }catch(ArithmeticException e){
            System.out.println("Error división entre cero");
        }
        
    }
    
}
