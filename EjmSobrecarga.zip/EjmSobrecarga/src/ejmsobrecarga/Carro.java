/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejmsobrecarga;

/**
 *
 * @author UCLAB300
 */
public class Carro {
    String placa;
    String marca;
    String modelo;
    String color;
    double kilometraje;

    public Carro(String placa, String marca) {
        this.placa = placa;
        this.marca = marca;
    }
    public Carro(){
        
    }
    
    
    
    void verCarro(){
        System.out.println("Carro: PLACA: "+ this.placa + " MARCA: "+ this.marca+
                " MODELO: "+ this.modelo + " COLOR: "+ this.color + "KILOMETRAJE: "
                        + this.kilometraje);         
    }
}