/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejmsobrecarga;

/**
 *
 * @author UCLAB300
 */
public class EjmSobrecarga {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*Calculadora c= new Calculadora();
        System.out.println("Sumando 2 números:");
        c.sumar(7.3, 10.7);
        System.out.println("Sumando 3 números");
        c.sumar(7, 5, 3);
        System.out.println("Sumando 4 números");
        c.sumar(7, 5, 3,10);*/
       
       // Calculadora.sumar(7,5);
        Calculadora c = new Calculadora();
        c.sumar(7, 5);
        Calculadora.sumar(15.3, 8.7,3.7);
        Calculadora.sumar(7, 5,8,1);
        
        Carro car = new Carro("SIN PLACA", "TOYOTA");
        car.verCarro();
        
        Carro car1 = new Carro();
        
        Calculadora c1 = new Calculadora();
        c1.dividir(8,0 );
    }
    
}
