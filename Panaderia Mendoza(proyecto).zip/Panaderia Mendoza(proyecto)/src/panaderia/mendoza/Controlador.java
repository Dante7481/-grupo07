/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package panaderia.mendoza;

import java.util.ArrayList;

/**
 *
 * @author juanc
 */
public class Controlador {
    private ArrayList<Cliente> clientes = new ArrayList<>();
    private ArrayList<Producto> productos = new ArrayList<>();

    // Métodos para Cliente
    public void agregarCliente(String nombre, String telefono, String direccion, String correo) {
        Cliente nuevoCliente = new Cliente(nombre, telefono, direccion, correo);
        clientes.add(nuevoCliente);
        System.out.println("¡Cliente agregado!");
    }

    public void mostrarClientes() {
        System.out.println("----- Lista de Clientes -----");
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes registrados.");
        } else {
            for (Cliente c : clientes) {
                System.out.println(c);
            }
        }
    }

    public void buscarClientePorTelefono(String telefonoBuscado) {
        boolean encontrado = false;
        for (Cliente c : clientes) {
            if (c.getTelefono().equals(telefonoBuscado)) {
                System.out.println("Cliente encontrado:");
                System.out.println(c);
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontro un cliente con el telefono: " + telefonoBuscado);
        }
    }

    // Métodos para Producto
    public void agregarProducto(String nombre, double precio, int stock) {
        Producto nuevoProducto = new Producto(nombre, precio, stock);
        productos.add(nuevoProducto);
        System.out.println(" Producto agregado ");
    }

    public void mostrarProductos() {
        System.out.println(" Lista de Productos ");
        if (productos.isEmpty()) {
            System.out.println(" No hay productos registrados ");
        } else {
            for (Producto p : productos) {
                System.out.println(p);
            }
        }
    }
}
