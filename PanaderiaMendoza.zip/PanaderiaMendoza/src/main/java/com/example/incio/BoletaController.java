package com.example.incio;

import com.example.incio.Controlador.DatosController;
import com.example.incio.Modelo.DetalleVenta;
import com.example.incio.Modelo.Venta;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class BoletaController {
    @FXML
    private TextArea txtBoleta;

    @FXML
    private void initialize() {
        if (DatosController.ventas.isEmpty()) {
            txtBoleta.setText("No hay ventas registradas aún.");
            return;
        }

        Venta v = DatosController.ventas.get(DatosController.ventas.size() - 1);
        StringBuilder sb = new StringBuilder();
        sb.append("CLIENTE: ").append(v.getCliente().getNombre()).append("\n\n");
        sb.append("PRODUCTOS:\n");

        for (DetalleVenta d : v.getDetalles()) {
            sb.append("- ").append(d.getProducto().getNombre())
                    .append(" x").append(d.getCantidad())
                    .append(" = S/. ").append(String.format("%.2f", d.getSubtotal()))
                    .append("\n");
        }

        sb.append("\nTOTAL: S/. ").append(String.format("%.2f", v.getTotal()));
        sb.append("\n\nGRACIAS POR COMPRAR EN PANADERÍA MENDOZA");


        txtBoleta.setText(sb.toString());
    }
}
