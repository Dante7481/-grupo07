package com.example.incio;

import com.example.incio.Conexion.ClienteDAO;
import com.example.incio.Controlador.DatosController;
import com.example.incio.Modelo.Cliente;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

public class ClienteController {
    @FXML
    private TextField txtNombre;
    @FXML private TextField txtDni;
    @FXML private TextField txtTelefono;
    @FXML private TextField txtCorreo;
    @FXML private TextField txtLocalidad;

    @FXML
    private void registrarCliente() {
        String nombre = txtNombre.getText();
        String dni = txtDni.getText();
        String telefono = txtTelefono.getText();
        String correo = txtCorreo.getText();
        String localidad = txtLocalidad.getText();

        if (nombre.isEmpty() || dni.length() != 8 || telefono.length() != 9) {
            mostrarAlerta("Error", "Nombre, DNI y Telefono válido (8 dígitos) son requeridos.");
            return;
        }

        int id = DatosController.getClientes().size() + 1;

        // 3. Crear objeto Cliente
        Cliente cliente = new Cliente(nombre, dni, telefono, correo, localidad);

        // 4. Guardar en la base de datos
        ClienteDAO.guardarCliente(cliente);

        // 5. Confirmar al usuario
        mostrarAlerta("Éxito", "✅ Cliente registrado correctamente en la base de datos.");

        // 6. Limpiar campos
        limpiarCampos();

        mostrarAlerta("Éxito", "Cliente registrado correctamente.");
        limpiarCampos();
    }

    private void limpiarCampos() {
        txtNombre.clear();
        txtDni.clear();
        txtTelefono.clear();
        txtCorreo.clear();
        txtLocalidad.clear();
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

}
