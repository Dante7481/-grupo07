package com.example.incio.Conexion;

import com.example.incio.Modelo.Cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClienteAcceso {
    public static void guardarCliente(Cliente c) {
        String sql = "INSERT INTO Cliente (nombre, dni, telefono, correo, localidad) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, c.getNombre());
            ps.setString(2, c.getDni());
            ps.setString(3, c.getTelefono());
            ps.setString(4, c.getCorreo());
            ps.setString(5, c.getLocalidad());

            ps.executeUpdate();
            System.out.println("✅ Cliente guardado en la BD.");

        } catch (SQLException e) {
            System.out.println("❌ Error al guardar cliente: " + e.getMessage());
        }
    }
    public static List<Cliente> obtenerClientes() {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT id, nombre, dni, telefono, correo, localidad FROM Cliente";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Cliente c = new Cliente(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("dni"),
                        rs.getString("telefono"),
                        rs.getString("correo"),
                        rs.getString("localidad")
                );
                lista.add(c);
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al obtener clientes: " + e.getMessage());
        }

        return lista;
    }
}
