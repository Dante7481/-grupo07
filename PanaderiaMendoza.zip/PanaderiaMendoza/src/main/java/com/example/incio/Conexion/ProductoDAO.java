package com.example.incio.Conexion;

import com.example.incio.Modelo.Producto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {
    public static void guardarProducto(Producto producto) {
        String sql = "INSERT INTO Producto (nombre, precio, categoria, descripcion) VALUES (?, ?, ?, ?)";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, producto.getNombre());
            stmt.setDouble(2, producto.getPrecio());
            stmt.setString(3, producto.getCategoria());
            stmt.setString(4, producto.getDescripcion());

            stmt.executeUpdate();
            System.out.println("✅ Producto guardado en la base de datos.");

        } catch (SQLException e) {
            System.out.println("❌ Error al guardar producto: " + e.getMessage());
        }
    }
    public static List<Producto> obtenerProductos() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT id, nombre, precio, categoria, descripcion FROM Producto";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Producto p = new Producto(
                        rs.getString("Nombre"),
                        rs.getDouble("Precio"),
                        rs.getString("categoria"),
                        rs.getString("descripcion")
                );
                lista.add(p);
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al obtener productos: " + e.getMessage());
        }

        return lista;
    }
}
