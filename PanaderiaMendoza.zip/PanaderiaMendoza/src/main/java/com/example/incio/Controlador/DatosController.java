package com.example.incio.Controlador;

import com.example.incio.Modelo.Cliente;
import com.example.incio.Modelo.Producto;
import com.example.incio.Modelo.Vendedor;
import com.example.incio.Modelo.Venta;

import java.util.ArrayList;
import java.util.List;

public class DatosController {
    Vendedor vendedor = DatosController.vendedorActual;
    public static Vendedor vendedorActual;
    public static List<Cliente> clientes = new ArrayList<>();
    public static List<Producto> productos = new ArrayList<>();
    public static List<Venta> ventas = new ArrayList<>();
    public static List<Vendedor> vendedores = new ArrayList<>();

    public static void agregarVendedor(Vendedor v) {
        vendedores.add(v);
    }

    public static List<Vendedor> getVendedores() {
        return vendedores;
    }
    public static void agregarCliente(Cliente c) {
        clientes.add(c);
    }

    public static void agregarProducto(Producto p) {
        productos.add(p);
    }

    public static void agregarVenta(Venta v) {
        ventas.add(v);
    }

    public static List<Cliente> getClientes() {
        return clientes;
    }

    public static List<Venta> getVentas() {
        return ventas;
    }

}
