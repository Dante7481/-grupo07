package com.example.incio;

import com.example.incio.Controlador.DatosController;
import com.example.incio.Modelo.Vendedor;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;

import java.io.*;


public class HelloController{
    private void guardarSesion(Vendedor vendedor) {
        try (PrintWriter writer = new PrintWriter("session.txt")) {
            writer.println(vendedor.getNombre());
            writer.println(vendedor.getDni());
            writer.println(vendedor.getTelefono());
            writer.println(vendedor.getCargo());
        } catch (IOException e) {
            e.printStackTrace();
        }

        DatosController.vendedorActual = vendedor;
    }

    @FXML private TextField txtNombre;
    @FXML private TextField txtDni;
    @FXML private TextField txtTelefono;
    @FXML private TextField txtCargo;

    @FXML
    private void Ingresar() {
        if (DatosController.vendedorActual == null) {
            mostrarAlerta("Acceso denegado", "⚠️ Primero debe registrar al vendedor.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/incio/MenuPrincipal.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Menú Principal - Panadería Mendoza");
            stage.show();

            // Cerrar ventana de inicio
            Stage actual = (Stage) txtNombre.getScene().getWindow();
            actual.close();

        } catch (IOException e) {
            e.printStackTrace();
            mostrarAlerta("Error", "No se pudo abrir el menú principal.");
        }
    }
    @FXML
    private void abrirRegistroVendedor() {
        String nombre = txtNombre.getText();
        String dni = txtDni.getText();
        String telefono = txtTelefono.getText();
        String cargo = txtCargo.getText();

        if (nombre.isEmpty() || dni.isEmpty() || telefono.isEmpty() || cargo.isEmpty()) {
            mostrarAlerta("Campos obligatorios", "Por favor complete todos los campos.");
            return;
        }

        int id = DatosController.getVendedores().size() + 1;
        Vendedor nuevo = new Vendedor(id, nombre, dni, telefono, "", "", cargo);
        DatosController.agregarVendedor(nuevo);

        guardarSesion(nuevo); // ✅ Aquí se guarda la sesión correctamente
        mostrarAlerta("Registro Exitoso", "✅ Vendedor registrado correctamente.");
        limpiarCampos();
    }
    @FXML
    private void limpiarCampos() {
        txtNombre.clear();
        txtDni.clear();
        txtTelefono.clear();
        txtCargo.clear();
    }
    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
    @FXML
    public void initialize() {
        cargarSesion();
    }
    private void cargarSesion() {
        File archivo = new File("session.txt");
        if (archivo.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
                String nombre = reader.readLine();
                String dni = reader.readLine();
                String telefono = reader.readLine();
                String cargo = reader.readLine();

                Vendedor vendedor = new Vendedor(0, nombre, dni, telefono, "", "", cargo);
                DatosController.vendedorActual = vendedor;

                // Puedes también auto llenar los campos del formulario
                txtNombre.setText(nombre);
                txtDni.setText(dni);
                txtTelefono.setText(telefono);
                txtCargo.setText(cargo);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}