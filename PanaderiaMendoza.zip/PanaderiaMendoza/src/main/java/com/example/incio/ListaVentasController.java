package com.example.incio;

import com.example.incio.Controlador.DatosController;
import com.example.incio.Modelo.Venta;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;

public class ListaVentasController {
    @FXML
    private TableView<Venta> tablaVentas;
    @FXML private TableColumn<Venta, String> colVendedor;
    @FXML private TableColumn<Venta, String> colCliente;
    @FXML private TableColumn<Venta, String> colFecha;
    @FXML private TableColumn<Venta, Double> colTotal;
    private final DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    @FXML
    private void initialize() {
        colVendedor.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getVendedor().getNombre()));
        colCliente.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getCliente().getNombre()));

        colFecha.setCellValueFactory(
                data -> new SimpleStringProperty( data.getValue().getFecha().format(fmt) )
        );

        colTotal.setCellValueFactory(data ->
                new SimpleDoubleProperty(data.getValue().getTotal()).asObject());

        tablaVentas.setItems(FXCollections.observableArrayList(DatosController.getVentas()));
    }
}
