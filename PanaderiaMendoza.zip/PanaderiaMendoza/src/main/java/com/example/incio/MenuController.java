package com.example.incio;

import com.example.incio.Controlador.DatosController;
import com.example.incio.Modelo.Vendedor;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Label;


public class MenuController {

    @FXML
    private Label lblVendedor;

    @FXML
    public void initialize() {
        Vendedor vendedor = DatosController.vendedorActual;
        if (vendedor != null) {
            lblVendedor.setText("Sesión activa: " + vendedor.getNombre() + " (" + vendedor.getCargo() + ")");
        } else {
            lblVendedor.setText("Sesión activa: ---");
        }
    }

    // Abre cualquier ventana
    private void abrirVentana(String rutaFXML, String titulo) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle(titulo);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void abrirCliente() {
        abrirVentana("ClienteView.fxml", "Registrar Cliente");
    }

    @FXML
    private void abrirProducto() {
        abrirVentana("ProductoView.fxml", "Registrar Producto");
    }

    @FXML
    private void abrirVenta() {
        abrirVentana("VentaView.fxml", "Registrar Venta");
    }

    @FXML
    private void abrirVentas() {
        abrirVentana("ListaVentasView.fxml", "Historial de Ventas");
    }

    @FXML
    private void cerrar() {
        System.exit(0);
    }

    @FXML
    public void mostrarBoleta() {
        abrirVentana("BoletaView.fxml", "Boleta de Ventas");
    }

    @FXML
    private void mostrarRegistroVendedor() {
        abrirVentana("hello-view.fxml", "Registrar Vendedor");
    }
}
