package com.example.incio.Modelo;

import com.example.incio.Conexion.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Cliente extends Persona {
    public Cliente(int id, String nombre, String dni, String telefono, String correo, String localidad) {
        super(id, nombre, dni, telefono, correo, localidad);
    }

    public String verDatos() {
        return "Cliente: " + nombre + " | DNI: " + dni + " | Teléfono: " + telefono +
                " | Correo: " + correo + " | Localidad: " + localidad;
    }
    public Cliente(String nombre, String dni, String telefono, String correo, String localidad) {
        super(0, nombre, dni, telefono, correo, localidad); // id = 0 porque lo generará la BD
    }

    @Override
    public String toString() {
        return nombre;
    }

}
