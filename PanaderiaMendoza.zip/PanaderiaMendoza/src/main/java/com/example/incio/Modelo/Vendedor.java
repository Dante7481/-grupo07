package com.example.incio.Modelo;

public class Vendedor extends Persona {
    private String cargo;

    public Vendedor(int id, String nombre, String dni, String telefono, String correo, String localidad, String cargo) {
        super(id, nombre, dni, telefono, correo, localidad);
        this.cargo = cargo;
    }
    //Constructor sin ID (para inserción en la BD)
    public Vendedor(String nombre, String dni, String telefono, String correo, String localidad, String cargo) {
        super(0, nombre, dni, telefono, correo, localidad); // id = 0, lo genera la BD
        this.cargo = cargo;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String verDatos() {
        return "Vendedor: " + nombre + " | DNI: " + dni + " | Cargo: " + cargo;
    }

    @Override
    public String toString() {
        return nombre + " (" + cargo + ")";
    }
}
