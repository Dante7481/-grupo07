package com.example.incio.Modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Venta {
    private int id;
    private Cliente cliente;
    private Vendedor vendedor;
    private LocalDate fecha; // NUEVO
    private List<DetalleVenta> detalles;
    private double total;

    public Venta(int id, Cliente cliente, Vendedor vendedor) {
        this.id = id;
        this.cliente = cliente;
        this.vendedor = vendedor;
        this.fecha = LocalDate.now(); // Captura la fecha actual automáticamente
        this.detalles = new ArrayList<>();
        this.total = 0;
    }

    // Getters
    public int getId() { return id; }
    public Cliente getCliente() { return cliente; }
    public Vendedor getVendedor() { return vendedor; }
    public LocalDate getFecha() { return fecha; } // NUEVO
    public List<DetalleVenta> getDetalles() { return detalles; }
    public double getTotal() { return total; }

    public void agregarDetalle(DetalleVenta d) {
        detalles.add(d);
        total += d.getSubtotal();
    }
    public double calcularTotal() {
        double total = 0;
        for (DetalleVenta detalle : detalles) {
            total += detalle.getSubtotal();
        }
        return total;
    }
}
