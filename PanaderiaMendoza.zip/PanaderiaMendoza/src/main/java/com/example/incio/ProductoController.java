package com.example.incio;

import com.example.incio.Conexion.ProductoDAO;
import com.example.incio.Controlador.DatosController;
import com.example.incio.Modelo.Producto;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;

public class ProductoController {
    @FXML
    private TextField txtNombre;
    @FXML private TextField txtPrecio;
    @FXML private TextField txtCategoria;
    @FXML private TextField txtDescripcion;

    @FXML
    private void registrarProducto() {
        String nombre = txtNombre.getText();
        String precioTxt = txtPrecio.getText();
        String categoria = txtCategoria.getText();
        String descripcion = txtDescripcion.getText();

        if (nombre.isEmpty() || precioTxt.isEmpty()) {
            mostrarAlerta("Error", "Nombre y precio son requeridos.");
            return;
        }

        try {
            double precio = Double.parseDouble(precioTxt);
            Producto p = new Producto(nombre, precio, categoria, descripcion);
            ProductoDAO.guardarProducto(p); // ✅ ahora también se guarda en la base de datos
            DatosController.agregarProducto(p); // opcional, si sigues usando la lista local

            mostrarAlerta("Éxito", "Producto registrado correctamente.");
            limpiarCampos();
        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "El precio debe ser un número válido.");
        }
    }

    private void limpiarCampos() {
        txtNombre.clear();
        txtPrecio.clear();
        txtCategoria.clear();
        txtDescripcion.clear();
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
