package com.example.incio;

import com.example.incio.Conexion.ClienteDAO;
import com.example.incio.Conexion.ProductoDAO;
import com.example.incio.Controlador.DatosController;
import com.example.incio.Modelo.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class VentaController {

    @FXML private ComboBox<Cliente> cbCliente;
    @FXML private ComboBox<Producto> cbProducto;
    @FXML private TextField txtCantidad;
    @FXML private TableView<DetalleVenta> tablaDetalle;
    @FXML private TableColumn<DetalleVenta, String> colProducto;
    @FXML private TableColumn<DetalleVenta, Integer> colCantidad;
    @FXML private TableColumn<DetalleVenta, Double> colSubtotal;
    @FXML private Label lblTotal;

    private ObservableList<DetalleVenta> listaDetalle = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        // Llenar combos
        cbCliente.setItems(FXCollections.observableArrayList(DatosController.getClientes()));
        cbProducto.setItems(FXCollections.observableArrayList(DatosController.productos));

        // Columnas de la tabla
        colProducto.setCellValueFactory(
                data -> new SimpleStringProperty(
                        data.getValue().getProducto().getNombre())
        );

        colCantidad.setCellValueFactory(
                data -> new SimpleIntegerProperty(
                        data.getValue().getCantidad()).asObject()
        );

        colSubtotal.setCellValueFactory(
                data -> new SimpleDoubleProperty(
                        data.getValue().getSubtotal()).asObject()
        );

        // Enlazar la lista observable con la tabla
        tablaDetalle.setItems(listaDetalle);
        cbCliente.setItems(FXCollections.observableArrayList(ClienteDAO.obtenerClientes()));
        cbProducto.setItems(FXCollections.observableArrayList(ProductoDAO.obtenerProductos()));

        // Configurar cómo mostrar los elementos (opcional si ya usas toString() en Cliente y Producto)
        cbCliente.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(Cliente item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getNombre());
            }
        });
        cbCliente.setButtonCell(cbCliente.getCellFactory().call(null));

        cbProducto.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(Producto item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getNombre() + " (S/. " + item.getPrecio() + ")");
            }
        });
        cbProducto.setButtonCell(cbProducto.getCellFactory().call(null));
    }

    @FXML
    private void agregarProducto() {
        Producto p = cbProducto.getValue();
        String cantidadTxt = txtCantidad.getText();

        if (p == null || cantidadTxt.isEmpty()) return;

        try {
            int cantidad = Integer.parseInt(cantidadTxt);
            DetalleVenta d = new DetalleVenta(p, cantidad, p.getPrecio());
            listaDetalle.add(d);
            actualizarTotal();
            txtCantidad.clear();
        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "Cantidad no válida.");
        }
    }

    private void actualizarTotal() {
        double total = listaDetalle.stream().mapToDouble(DetalleVenta::getSubtotal).sum();
        lblTotal.setText("S/. " + String.format("%.2f", total));
    }

    @FXML
    private void registrarVenta() {
        Cliente c = cbCliente.getValue();
        if (c == null || listaDetalle.isEmpty()) {
            mostrarAlerta("Error", "Seleccione cliente y al menos un producto.");
            return;
        }
        Vendedor vendedor = DatosController.vendedorActual;
        if (vendedor == null) {
            mostrarAlerta("Error", "No hay vendedor activo. Inicie sesión.");
            return;
        }
        Venta venta = new Venta(DatosController.getVentas().size() + 1, c, vendedor);
        Venta v = new Venta(DatosController.getVentas().size() + 1, c, DatosController.vendedorActual);
        for (DetalleVenta d : listaDetalle) {
            v.agregarDetalle(d);
        }
        DatosController.agregarVenta(v);
        guardarBoletaEnArchivo(venta);
        mostrarAlerta("Éxito", "Venta registrada con éxito.");
        cbCliente.getSelectionModel().clearSelection();
        cbProducto.getSelectionModel().clearSelection();
        listaDetalle.clear();
        actualizarTotal();
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
    private void guardarBoletaEnArchivo(Venta venta) {
        try {
            // Crear carpeta boletas si no existe
            File carpeta = new File("boletas");
            if (!carpeta.exists()) carpeta.mkdir();

            // Nombre de archivo (ej. boleta_001.txt)
            String nombreArchivo = "boleta_" + String.format("%03d", venta.getId()) + ".txt";
            File archivo = new File(carpeta, nombreArchivo);

            try (PrintWriter writer = new PrintWriter(archivo)) {
                writer.println("==================================================");
                writer.println("            PANADERÍA MENDOZA - BOLETA");
                writer.println("==================================================");
                writer.printf("Boleta Nº: %03d\n", venta.getId());
                writer.println("Fecha    : " + venta.getFecha());

                writer.println();
                writer.println("Cliente  : " + venta.getCliente().getNombre());
                writer.println("DNI      : " + venta.getCliente().getDni());
                writer.println("Vendedor : " + venta.getVendedor().getNombre() +
                        " (" + venta.getVendedor().getCargo() + ")");

                writer.println();
                writer.println("--------------------------------------------------");
                writer.println("Producto                 Cant.     Precio     Subtotal");
                writer.println("--------------------------------------------------");

                for (DetalleVenta d : venta.getDetalles()) {
                    String nombre = d.getProducto().getNombre();
                    int cantidad = d.getCantidad();
                    double precio = d.getProducto().getPrecio();
                    double subtotal = d.getSubtotal();

                    writer.printf("%-25s %5d     %6.2f     %7.2f\n",
                            nombre, cantidad, precio, subtotal);
                }

                writer.println("--------------------------------------------------");
                writer.printf("TOTAL A PAGAR:%36sS/. %.2f\n", "", venta.calcularTotal());
                writer.println("==================================================");
                writer.println("     ¡GRACIAS POR COMPRAR EN PANADERÍA MENDOZA!");
                writer.println("==================================================");
            }

            System.out.println("✅ Boleta guardada en archivo: " + archivo.getAbsolutePath());

        } catch (IOException e) {
            System.out.println("❌ Error al guardar boleta: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
