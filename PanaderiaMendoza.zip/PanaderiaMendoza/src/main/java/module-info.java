module com.example.incio {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;
    requires java.desktop;
    requires java.sql;

    opens com.example.incio to javafx.fxml;
    exports com.example.incio;
    exports com.example.incio.Controlador;
    opens com.example.incio.Controlador to javafx.fxml;
    exports com.example.incio.Conexion;
    opens com.example.incio.Conexion to javafx.fxml;
}