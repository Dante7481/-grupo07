/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package panaderiamendoza;

import java.util.Scanner;

/**
 *
 * @author juanc
 */
public class Controlador {
    private SistemaPanaderia sistema;
    private Scanner scanner;

    public Controlador() {
        sistema = new SistemaPanaderia();
        scanner = new Scanner(System.in);
        sistema.cargarClientesDesdeArchivo();
        sistema.cargarProductosDesdeArchivo();
    }

    public void iniciar() {
        int opcion;
        do {
            System.out.println("\n---- MENU PANADERIA MENDOZA ----");
            System.out.println("1. Registrar cliente");
            System.out.println("2. Registrar producto");
            System.out.println("3. Mostrar clientes");
            System.out.println("4. Mostrar productos");
            System.out.println("5. Realizar venta");
            System.out.println("6. Mostrar boletas");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1 -> registrarCliente();
                case 2 -> registrarProducto();
                case 3 -> sistema.mostrarClientes();
                case 4 -> sistema.mostrarProductos();
                case 5 -> realizarVenta();
                case 6 -> sistema.mostrarBoletas();
                case 0 -> System.out.println("Saliendo del sistema...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 0);

        sistema.guardarClientesEnArchivo();
        sistema.guardarProductosEnArchivo();
    }

    private void registrarCliente() {
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("DNI: ");
        String dni = scanner.nextLine();
        System.out.print("Localidad: ");
        String localidad = scanner.nextLine();
        System.out.print("TelEfono: ");
        String telefono = scanner.nextLine();
        System.out.print("Correo: ");
        String correo = scanner.nextLine();

        try {
            Cliente c = new Cliente(nombre, dni, localidad, telefono, correo);
            sistema.agregarCliente(c);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void registrarProducto() {
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Precio: ");
        double precio = scanner.nextDouble();
        System.out.print("Stock: ");
        int stock = scanner.nextInt();
        scanner.nextLine(); // limpiar buffer
        System.out.print("Categoria: ");
        String categoria = scanner.nextLine();
        System.out.print("Descripcion: ");
        String descripcion = scanner.nextLine();

        try {
            Producto p = new Producto(nombre, precio, stock, categoria, descripcion);
            sistema.registrarProducto(p);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void realizarVenta() {
        if (sistema.getClientes().isEmpty() || sistema.getProductos().isEmpty()) {
            System.out.println("Debe haber al menos un cliente y un producto.");
            return;
        }

        System.out.println("Seleccione cliente por indice:");
        for (int i = 0; i < sistema.getClientes().size(); i++) {
            System.out.println(i + ". " + sistema.getClientes().get(i).getNombre());
        }
        int idxCliente = scanner.nextInt();
        Cliente cliente = sistema.getClientes().get(idxCliente);

        Venta venta = new Venta(cliente);

        boolean seguir = true;
        while (seguir) {
            System.out.println("Seleccione producto por índice:");
            for (int i = 0; i < sistema.getProductos().size(); i++) {
                System.out.println(i + ". " + sistema.getProductos().get(i).getNombre());
            }
            int idxProducto = scanner.nextInt();
            Producto producto = sistema.getProductos().get(idxProducto);

            System.out.print("Cantidad: ");
            int cantidad = scanner.nextInt();

            venta.agregarProducto(producto, cantidad);

            System.out.print("¿Agregar otro producto? (s/n): ");
            scanner.nextLine(); // limpiar buffer
            String resp = scanner.nextLine();
            seguir = resp.equalsIgnoreCase("s");
        }

        venta.calcularTotal();
        venta.verDatos();
        sistema.realizarVenta(venta);
    }
}
