/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package panaderiamendoza;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 *
 * @author juanc
 */
public class SistemaPanaderia {
    private ArrayList<Cliente> clientes;
    private ArrayList<Producto> productos;
    private ArrayList<Venta> ventas;

    public SistemaPanaderia() {
        clientes = new ArrayList<>();
        productos = new ArrayList<>();
        ventas = new ArrayList<>();
    }

    // ---- CLIENTES ----
    public void agregarCliente(Cliente c) {
        for (Cliente cliente : clientes) {
            if (cliente.getDni().equals(c.getDni())) {
                System.out.println("El cliente con DNI ya existe.");
                return;
            }
        }
        clientes.add(c);
    }

    public void mostrarClientes() {
        for (Cliente c : clientes) {
            c.verDatos();
        }
    }

    public void guardarClientesEnArchivo() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("clientes.txt"))) {
            for (Cliente c : clientes) {
                pw.println(c.getDni() + "," + c.getNombre() + "," + c.getLocalidad() + "," + c.getTelefono() + "," + c.getCorreo());
            }
        } catch (IOException e) {
            System.out.println("Error al guardar clientes: " + e.getMessage());
        }
    }

    public void cargarClientesDesdeArchivo() {
        clientes.clear();
        try (BufferedReader br = new BufferedReader(new FileReader("clientes.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length == 5) {
                    Cliente c = new Cliente(datos[1], datos[0], datos[2], datos[3], datos[4]);
                    clientes.add(c);
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo cargar clientes: " + e.getMessage());
        }
    }

    // ---- PRODUCTOS ----
    public void registrarProducto(Producto p) {
        for (Producto prod : productos) {
            if (prod.getNombre().equalsIgnoreCase(p.getNombre())) {
                System.out.println("El producto ya existe.");
                return;
            }
        }
        productos.add(p);
    }

    public void mostrarProductos() {
        for (Producto p : productos) {
            p.verDatos();
        }
    }

    public void guardarProductosEnArchivo() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("productos.txt"))) {
            for (Producto p : productos) {
                pw.println(p.getNombre() + "," + p.getPrecio() + "," + p.getStock() + "," + p.getCategoria() + "," + p.getDescripcion());
            }
        } catch (IOException e) {
            System.out.println("Error al guardar productos: " + e.getMessage());
        }
    }

    public void cargarProductosDesdeArchivo() {
        productos.clear();
        try (BufferedReader br = new BufferedReader(new FileReader("productos.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length == 5) {
                    Producto p = new Producto(datos[0], Double.parseDouble(datos[1]), Integer.parseInt(datos[2]), datos[3], datos[4]);
                    productos.add(p);
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo cargar productos: " + e.getMessage());
        }
    }

    // ---- VENTAS ----
    public void realizarVenta(Venta venta) {
        ventas.add(venta);
        guardarVentasEnArchivo();
    }

    public void mostrarBoletas() {
        for (Venta v : ventas) {
            v.verDatos();
        }
    }

    public void guardarVentasEnArchivo() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("ventas.txt", true))) {
            for (Venta v : ventas) {
                pw.println("CLIENTE: " + v.getCliente().getNombre() + " - DNI: " + v.getCliente().getDni());
                for (Producto p : v.productos) {
                    pw.println("  " + p.getNombre() + " x" + p.getStock() + " = S/ " + (p.getPrecio() * p.getStock()));
                }
                pw.println("TOTAL: S/ " + v.getTotal());
                pw.println("-----");
            }
        } catch (IOException e) {
            System.out.println("Error al guardar ventas: " + e.getMessage());
        }
    }

    // Getters para uso desde el menú
    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }
}
