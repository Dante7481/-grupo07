/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package panaderiamendoza;

import java.util.ArrayList;

/**
 *
 * @author juanc
 */
public class Venta {
    private Cliente cliente;
    ArrayList<Producto> productos;
    private double total;

    public Venta(Cliente cliente) {
        this.cliente = cliente;
        this.productos = new ArrayList<>();
        this.total = 0.0;
    }

    public void agregarProducto(Producto producto, int cantidad) {
        if (producto.getStock() >= cantidad) {
            Producto copia = new Producto(
                producto.getNombre(),
                producto.getPrecio(),
                cantidad,
                producto.getCategoria(),
                producto.getDescripcion()
            );
            productos.add(copia);
            producto.setStock(producto.getStock() - cantidad);
            total += copia.getPrecio() * cantidad;
        } else {
            System.out.println("Stock insuficiente para el producto: " + producto.getNombre());
        }
    }

    public void calcularTotal() {
        total = 0;
        for (Producto p : productos) {
            total += p.getPrecio() * p.getStock();
        }
    }

    public double getTotal() {
        return total;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void verDatos() {
        System.out.println("----- BOLETA DE VENTA -----");
        System.out.println("Cliente: " + cliente.getNombre() + " - DNI: " + cliente.getDni());
        for (Producto p : productos) {
            System.out.println("- " + p.getNombre() + " x" + p.getStock() + " = S/ " + (p.getPrecio() * p.getStock()));
        }
        System.out.println("Total: S/ " + total);
        System.out.println("---------------------------");
    }    
}
