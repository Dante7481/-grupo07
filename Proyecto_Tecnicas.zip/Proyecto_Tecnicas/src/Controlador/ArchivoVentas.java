/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Venta;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author juanc
 */
public class ArchivoVentas {
    private static final String ARCHIVO = "ventas.txt";

    public static void guardarVenta(Venta venta) {
        try (FileWriter fw = new FileWriter(ARCHIVO, true)) {
            fw.write(venta.exportarVenta());
            fw.flush();
        } catch (IOException e) {
            System.out.println("Error al guardar la venta: " + e.getMessage());
        }
    }
}
