/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.util.ArrayList;
import java.util.List;
import Modelo.Cliente;
import Modelo.Producto;
import Modelo.Venta;

/**
 *
 * @author juanc
 */
public class Controlador {
    public static List<Cliente> clientes = new ArrayList<>();
    public static List<Producto> productos = new ArrayList<>();
    public static List<Venta> ventas = new ArrayList<>();

    // Métodos auxiliares (opcionales)
    public static void agregarCliente(Cliente c) {
        clientes.add(c);
    }

    public static void agregarProducto(Producto p) {
        productos.add(p);
    }

    public static void registrarVenta(Venta v) {
        ventas.add(v);
    }

    public static void mostrarClientes() {
        for (Cliente c : clientes) {
            c.verDatos();
        }
    }

    public static void mostrarProductos() {
        for (Producto p : productos) {
            p.verDatos();
        }
    }

    public static void mostrarVentas() {
        for (Venta v : ventas) {
            v.verDatos();
        }
    }
}
