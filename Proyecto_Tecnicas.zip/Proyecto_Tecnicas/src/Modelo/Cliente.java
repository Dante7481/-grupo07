/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author juanc
 */
public class Cliente extends Persona{
    private String correo;
    private String localidad;

    public Cliente(int id, String nombre, String dni, String telefono, String correo, String localidad) {
        super(id, nombre, dni, telefono);
        this.correo = correo;
        this.localidad = localidad;
    }

    @Override
    public void verDatos() {
        super.verDatos();
        System.out.println("Correo: " + correo + ", Localidad: " + localidad);
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }
    
}
