/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Modelo.Persona;

/**
 *
 * @author juanc
 */
public class Vendedor extends Persona{
    private String cargo;

    public Vendedor(int id, String nombre, String dni, String telefono, String cargo) {
        super(id, nombre, dni, telefono);
        this.cargo = cargo;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    @Override
    public void verDatos() {
        super.verDatos();
        System.out.println("Cargo: " + cargo);
    }
}
