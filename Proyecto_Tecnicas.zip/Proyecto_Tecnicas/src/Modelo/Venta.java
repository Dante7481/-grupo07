/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Modelo.Vendedor;
import Modelo.DetalledeVenta;
import Modelo.Cliente;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/**
 *
 * @author juanc
 */
public class Venta {
    private int id;
    private Date fecha;
    private Cliente cliente;
    private Vendedor vendedor;
    private List<DetalledeVenta> detalles;
    private double total;

    public Venta(int id, Date fecha, Cliente cliente, Vendedor vendedor, List<DetalledeVenta> detalles, double total) {
        this.id = id;
        this.fecha = new Date();
        this.cliente = cliente;
        this.vendedor = vendedor;
        this.detalles = new ArrayList<>();;
        this.total = total;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    public List<DetalledeVenta> getDetalles() {
        return detalles;
    }

    public void setDetalles(List<DetalledeVenta> detalles) {
        this.detalles = detalles;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
    public void agregarDetalle(DetalledeVenta detalle) {
        detalles.add(detalle);
        calcularTotal();
    }

    public void calcularTotal() {
        total = 0.0;
        for (DetalledeVenta d : detalles) {
            total += d.getSubtotal();
        }
    }

    public void verDatos() {
        System.out.println("Venta ID: " + id);
        System.out.println("Fecha: " + fecha);
        cliente.verDatos();
        vendedor.verDatos();
        System.out.println("Detalles:");
        for (DetalledeVenta d : detalles) {
            System.out.println("- " + d.getProducto().getNombre() +
                    ", Cantidad: " + d.getCantidad() +
                    ", Subtotal: " + d.getSubtotal());
        }
        System.out.println("TOTAL: S/. " + total);
    }
    public String exportarVenta() 
    {
    StringBuilder sb = new StringBuilder();
    sb.append("VENTA ID: ").append(id).append("\n");
    sb.append("Fecha: ").append(fecha).append("\n");
    sb.append("Cliente: ").append(cliente.getNombre()).append(" - DNI: ").append(cliente.getDni()).append("\n");
    sb.append("Productos:\n");
    for (DetalledeVenta d : detalles) {
        sb.append(" - ").append(d.getProducto().getNombre())
          .append(" x ").append(d.getCantidad())
          .append(" = S/. ").append(d.getSubtotal()).append("\n");
    }
    sb.append("TOTAL: S/. ").append(String.format("%.2f", total)).append("\n");
    sb.append("--------------------------------------------------\n");
    return sb.toString();
    }
}
